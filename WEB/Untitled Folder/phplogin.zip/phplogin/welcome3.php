
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <link rel="icon" href="images/favicon.jpg">

    <title>PHP | Login</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="starter-template.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>
    <link href="css/style.css" rel="stylesheet">
    <link href="css/figure.css" rel="stylesheet">

  </head>
  <body>


    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span> PHP</h1>
          </div>
        </div>
      </div>
    </header>
<br><br><br>


        <div class="container">
          <div class="row">
            <div class="wrap-login col-md-4 col-md-offset-4">
              <?php
                //include('session.php');
                echo "Login Successful...Redirecting!!!";
                //header( "refresh:2;url=welcome3.php" );
                
                ?>
              </div>
            </div>
        </div>
        <img src="images/mca3.jpg" align="center" style="width:450px;height:450px;">
        <div class="btn-group" role="group">
                  <button type="button" class="btn btn-default main-color-bg" onclick="window.location.href='logout.php'">Logout</button>
                </div>





    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
